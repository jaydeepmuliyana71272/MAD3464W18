/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class inheritance 
{
    public static void main(String[] args)
    {
        person p1 = new person(); 
        //p1.readData(); 
       // p1.displayData(); 
        
        person p2 = new person("JD","JAY",22);  
       // p2.displayData(); 
        
        person p3 = new person(p2);
       // p3.displayData(); 
        
       // Employee e1 = new Employee(1450.87); 
      //  e1.display(); 
        
        Employee e2 = new Employee(); 
        e2.display(); 
        
        e2.firstName = "JD"; 
        e2.lastName = "JAY"; 
        e2.age = 22; 
        e2.salary = 1100; 
       // e2.displayData(); 
        e2.display(); 
        //System.out.println("First: "+e2.firstName);
        Employee e3 = new Employee();
        e3.read(); 
        e3.display(); 
    }
}
