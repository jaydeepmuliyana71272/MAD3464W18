
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class Employee extends person 
{
    double salary; 
    
    Employee()
    {
        super(); 
        this.salary = 14; 
    } 
    
    Employee(String fName, String lName, int age, double pay) 
    {
        super(fName,lName,age); 
        this.salary = pay; 
    } 
    
    void read()
    {
        super.read(); 
        Scanner input = new Scanner(System.in); 
        System.out.println("Enter Salary: "); 
        this.salary = input.nextDouble(); 
    }
    
    void display() 
    {
        super.display(); 
        System.out.println("Salary: "+this.salary); 
    }
}
