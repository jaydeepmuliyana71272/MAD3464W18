/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */


import java.util.Scanner; 

public class OOPClasses 
{
    public static void main(String[] args) 
    {
        Bank myBank = new Bank(); 
        System.out.println("Bank ID:"+myBank.bankId); 
        System.out.println("Bank Name:"+myBank.bankName); 
        
        Bank yourBank = new Bank(); 
        myBank.bankId = 1231; 
        myBank.bankName = "RBC"; 
        
        System.out.println("Bank ID:"+myBank.bankId); 
        System.out.println("Bank Name:"+myBank.bankName); 
        
        
        yourBank.getBankName(); 
        yourBank.setBankName("ICICI"); 
        yourBank.getBankName(); 
        
        Scanner myInput = new Scanner(System.in); 
        String name; 
        System.out.println("Enter Bank Name:"); 
        name = myInput.nextLine(); 
        yourBank.setBankName(name); 
        System.out.println("Added Bank Name: "+yourBank.bankName); 
        
        
        Arithmetic op1 = new Arithmetic(); 
        System.out.println("Int Answer : "+op1.Addition(10, 20)); 
        System.out.println("3 Answer : "+op1.Addition(10, 20, 30)); 
        System.out.println("Float Answer : "+op1.Addition(10.23f, 20.45f)); 
        
        System.out.println("Multiplication: "+op1.multiplication(10,20,30)); 
        Arithmetic.multiplication(10,20); 
       // Arithmetic.Addition(10,20); 
       
       Arithmetic.n1 = 20; 
       //Arithmetic.n2 = 20; 
       System.out.println(Arithmetic.n1+ " "+Arithmetic.n2); 
       
    }
}
