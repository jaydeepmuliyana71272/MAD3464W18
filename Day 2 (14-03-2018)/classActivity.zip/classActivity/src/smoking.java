
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class smoking 
{
    int[] seat; 
    int i,c;
    
    void book()
    {
        System.out.println("Enter Seat Number from 1 to 5: "); 
        Scanner input = new Scanner(System.in); 
        this.i = input.nextInt();
        //seat[i] = 1;
        if (this.i >= 6 && seat[i] != 1)
                {
                    System.out.println("Either seat is booked or number is greater than 5");
                    book(); 
                }
        else
        {
            //seat[i] = 1;
            System.out.println("**********************");
            System.out.println("Your Seat is reserved"); 
            System.out.println("Section : Smoking");
            System.out.println("Seat no.: "+this.i); 
            System.out.println("1) Book 2) Exit");
            Scanner select = new Scanner(System.in); 
            this.c = input.nextInt();
            if(c == 1)
            {
                book(); 
            }
            else if(c ==2)
            {
                System.out.println("Thank you For Booking"); 
            }  
        }
    }
}
