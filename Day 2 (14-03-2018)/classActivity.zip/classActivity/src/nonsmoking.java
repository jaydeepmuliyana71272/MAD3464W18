
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class nonsmoking 
{
    int[] seat; 
    int i,c;
    void book()
    {
        System.out.println("Enter Seat Number from 6 to 10: "); 
        Scanner input = new Scanner(System.in); 
        this.i = input.nextInt(); 
        if (this.i <= 5 && this.i >= 11)
                {
                    System.out.println("Enter Between 6 to 10");
                    book(); 
                }
        else
        {
            System.out.println("**********************");
            System.out.println("Your Seat is reserved"); 
            System.out.println("Section : Non-Smoking");
            System.out.println("Seat no.: "+this.i); 
            System.out.println("1) Book 2) Exit");
            Scanner select = new Scanner(System.in); 
            this.c = input.nextInt();
            if(c == 1)
            {
                book(); 
            }
            else if(c ==2)
            {
                System.out.println("Thank you For Booking"); 
            }  
        }
    }
}
