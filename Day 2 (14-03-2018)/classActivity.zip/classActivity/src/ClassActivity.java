
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author macstudent
 */
public class ClassActivity {

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int choose; 
        
        System.out.println("Select Section: ");
        System.out.println("1) Smoking Section: ");
        System.out.println("2)Non-Smoking Section: "); 
        
        Scanner input = new Scanner(System.in); 
        choose = input.nextInt(); 
        
        
        
        if(choose == 1)
        {
         smoking s = new smoking(); 
         s.book(); 
        }
        else if(choose == 2) 
        {
            nonsmoking ns = new nonsmoking(); 
            ns.book(); 
        }
        else 
        {
            System.out.println("Enter Valid Number");
        }
        }
   
    
}
